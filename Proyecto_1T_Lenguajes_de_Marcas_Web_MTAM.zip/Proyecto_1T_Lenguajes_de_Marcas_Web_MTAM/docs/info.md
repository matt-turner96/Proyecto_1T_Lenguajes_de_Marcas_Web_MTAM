### Descripción
Este sitio web ha sido creado para Sketchers Hotels, una empresa ficticia. Alex y yo hemos desarrollado varias páginas para demostrar nuestras habilidades en HTML y CSS. El sitio incluye páginas de reservas, contacto y presentación del equipo. Nuestro objetivo era que pareciera una página web real y que los usuarios pudieran navegar por ella como si estuvieran realizando reservas o consultando precios de hoteles.

Las páginas incluyen diversos elementos, como tablas, formularios, listas y mucho más. Según GitHub, aproximadamente el 80 % del código está escrito en HTML y el 20 % en CSS.

### Sistema operativos
- Windows XP or later
- macOS 10.4 or later
- Any modern Linux distribution

### Ejecutar el programa
Se puede descargar el proyecto en github: https://github.com/matt-turner96/Proyecto_1T_Lenguajes_de_Marcas_Web_MTAM/blob/main/proyecto.zip
Descarga el zip
Guarda el proyecto
Deberías poder ver las páginas.

















## SKETCHERS
Best match: Cinzel Bold

A formal, elegant serif with classical Roman-style lettering. It's a good starting point for the logo, although the original font cannot be identified with certainty from the image alone.

## SUBTITLE — HOTEL
H O T E L
Best match: Montserrat Light

Use a thin sans-serif font with generous letter spacing to reproduce the refined subtitle.

## CSS colour palette
These are approximate colours sampled from your logo. The artwork has some texture and tonal variation, so the exact original design colours may differ slightly.

Sage green
#6D835B
Main logo lettering and icon

Copy


Golden yellow
#EFD063
Subtitle, roof and decorative lines

Copy


White
#FFFFFF
Logo background

