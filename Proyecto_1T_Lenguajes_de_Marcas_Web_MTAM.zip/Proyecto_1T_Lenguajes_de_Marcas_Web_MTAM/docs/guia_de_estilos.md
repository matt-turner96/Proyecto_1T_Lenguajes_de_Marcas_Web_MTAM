Guía de estilos Hotel Sketchers

1. Colores
Teal #2f6f73 Títulos, botones y bordes 
Amarillo #EFD063 Header y footer 
Gris oscuro #1c1c1c Texto 

2. Tipografía 
Una sola fuente en todo el sitio: Segoe UI .
• Título principal (h1): 32 px 
• Subtítulos (h2): 26 px • Títulos pequeños (h3): 20 px 
• Párrafos: 16 px 

3. Componentes 
• .container — centra el contenido de la página. 
• .navbar — menú de navegación. 
• .btn — botón. 
• .card — tarjeta. 
• .grid — pone tarjetas en columnas.
• .footer — pie de página. 

4. Normas 
• Los estilos se ponen con class. No se usa style dentro del HTML. 
• Todas las páginas tienen el mismo header, menú y footer. 
• Todos los enlaces entre páginas funcionan (index, reservacion, servicios, equipo, contacto). 
• Una sola hoja de estilos para todo el sitio: styles.css.
